#include "GPSError.h"

GPSError::GPSError(std::string msg) : Error(msg)
{
}

GPSError::~GPSError()
{

}

