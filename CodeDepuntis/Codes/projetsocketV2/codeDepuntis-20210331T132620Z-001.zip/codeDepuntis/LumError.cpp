#include "LumError.h"

LumError::LumError(std::string msg) : Error(msg)
{
}

LumError::~LumError()
{
    //dtor
}
